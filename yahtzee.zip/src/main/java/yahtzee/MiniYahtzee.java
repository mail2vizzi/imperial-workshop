package yahtzee;

class MiniYahtzee {

    public static void main(String[] args) {
    	
        new DiceScores().score(args[0], args[1], args[2], args[3]);
    }
    
 }




