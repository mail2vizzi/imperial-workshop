/**
 * 
 */
/**
 * 
 */
module yahtzee_module1 {
}